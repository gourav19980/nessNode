User Json sample.
{
    "id": 0,
    "name": "John Doe",
    "email": "johndoe@example.com"
}

GET
To read file http://localhost:3000/files/sample.txt


DELETE
To delete user based on Id http://localhost:3000/api/users/1


PUT
To update the user http://localhost:3000/api/users/1

GET
To get list of users http://localhost:3000/api/users
