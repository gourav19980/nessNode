const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = 3000;
const users = [];

// Simple request logger middleware
const logRequest = (req) => {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${req.method} ${req.url}`);
};

// Utility to parse JSON request body
const parseJSON = (req) => {
    return new Promise((resolve, reject) => {
        let body = "";
        req.on("data", (chunk) => (body += chunk));
        req.on("end", () => {
            try {
                resolve(JSON.parse(body));
            } catch {
                reject("Invalid JSON");
            }
        });
    });
};

// Create server
const server = http.createServer(async (req, res) => {
    logRequest(req);

    if (req.method === "GET" && req.url === "/") {
        res.writeHead(200, { "Content-Type": "text/plain" });
        return res.end("Welcome to the Custom HTTP Server");
    }

    if (req.url.startsWith("/api/users")) {
        if (req.method === "GET") {
            res.writeHead(200, { "Content-Type": "application/json" });
            return res.end(JSON.stringify(users));
        }

        if (req.method === "POST") {
            try {
                const body = await parseJSON(req);
                const newUser = { id: users.length + 1, ...body };
                users.push(newUser);
                res.writeHead(201, { "Content-Type": "application/json" });
                return res.end(JSON.stringify(newUser));
            } catch {
                res.writeHead(400, { "Content-Type": "text/plain" });
                return res.end("Invalid JSON");
            }
        }

        if (req.method === "PUT") {
            try {
                const body = await parseJSON(req);
                const user = users.find((u) => u.id === body.id);
                if (user) {
                    Object.assign(user, body);
                    res.writeHead(200, { "Content-Type": "application/json" });
                    return res.end(JSON.stringify(user));
                }
                res.writeHead(404, { "Content-Type": "text/plain" });
                return res.end("User not found");
            } catch {
                res.writeHead(400, { "Content-Type": "text/plain" });
                return res.end("Invalid JSON");
            }
        }

        if (req.method === "DELETE") {
            try {
                const body = await parseJSON(req);
                const index = users.findIndex((u) => u.id === body.id);
                if (index !== -1) {
                    users.splice(index, 1);
                    res.writeHead(200, { "Content-Type": "text/plain" });
                    return res.end("User deleted");
                }
                res.writeHead(404, { "Content-Type": "text/plain" });
                return res.end("User not found");
            } catch {
                res.writeHead(400, { "Content-Type": "text/plain" });
                return res.end("Invalid JSON");
            }
        }
    }

    if (req.url.startsWith("/files/")) {
        const filePath = path.join(__dirname, "public", req.url.replace("/files/", ""));
        fs.readFile(filePath, (err, data) => {
            if (err) {
                res.writeHead(404, { "Content-Type": "text/plain" });
                return res.end("File not found");
            }
            res.writeHead(200, { "Content-Type": "application/octet-stream" });
            res.end(data);
        });
        return;
    }

    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("404 Not Found");
});

// Start server
server.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
