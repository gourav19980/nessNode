const { MongoClient } = require('mongodb');
const client = new MongoClient('mongodb://localhost:27017');

let db;
client.connect()
    .then(() => {
        db = client.db('shoppingCart');
        console.log('MongoDB Connected');
    })
    .catch(err => console.error('DB Connection Error:', err));

module.exports = { getDb: () => db };
