exports.register = async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ error: 'Missing fields' });
    const userCollection = req.db.collection('users');
    await userCollection.insertOne({ username, password });
    res.json({ message: 'User registered' });
};

exports.login = async (req, res) => {
    const { username, password } = req.body;
    const user = await req.db.collection('users').findOne({ username, password });
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    req.session.userId = user._id;
    res.json({ message: 'Login successful' });
};

exports.logout = (req, res) => {
    req.session.destroy();
    res.json({ message: 'Logged out' });
};
