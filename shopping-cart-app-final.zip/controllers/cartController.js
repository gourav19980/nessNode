exports.addToCart = async (req, res) => {
    if (!req.session.userId) return res.status(401).json({ error: 'Not logged in' });
    const { productId, quantity } = req.body;
    if (!productId || quantity <= 0) return res.status(400).json({ error: 'Invalid input' });

    const cartCollection = req.db.collection('carts');
    let cart = await cartCollection.findOne({ userId: req.session.userId });
    if (!cart) cart = { userId: req.session.userId, items: [] };
    const item = cart.items.find(i => i.productId === productId);
    if (item) item.quantity += quantity;
    else cart.items.push({ productId, quantity });

    await cartCollection.updateOne(
        { userId: req.session.userId },
        { $set: { items: cart.items } },
        { upsert: true }
    );
    res.json({ message: 'Item added to cart' });
};

exports.removeFromCart = async (req, res) => {
    if (!req.session.userId) return res.status(401).json({ error: 'Not logged in' });
    const cartCollection = req.db.collection('carts');
    let cart = await cartCollection.findOne({ userId: req.session.userId });
    if (!cart) return res.status(400).json({ error: 'Cart not found' });
    cart.items = cart.items.filter(i => i.productId !== req.params.productId);
    await cartCollection.updateOne(
        { userId: req.session.userId },
        { $set: { items: cart.items } }
    );
    res.json({ message: 'Item removed' });
};

exports.checkout = async (req, res) => {
    if (!req.session.userId) return res.status(401).json({ error: 'Not logged in' });
    const cartCollection = req.db.collection('carts');
    let cart = await cartCollection.findOne({ userId: req.session.userId });
    if (!cart || cart.items.length === 0) return res.status(400).json({ error: 'Cart is empty' });

    await cartCollection.deleteOne({ userId: req.session.userId });
    res.json({ message: 'Checkout successful' });
};
