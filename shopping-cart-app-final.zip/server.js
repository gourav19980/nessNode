const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const { MongoClient } = require('mongodb');
const authRoutes = require('./routes/authRoutes');
const productRoutes = require('./routes/productRoutes');
const cartRoutes = require('./routes/cartRoutes');

const app = express();
app.use(bodyParser.json());
app.use(session({ secret: 'shh-its-a-secret', resave: false, saveUninitialized: true }));

// Database Connection
const client = new MongoClient('mongodb://localhost:27017');
let db;
client.connect()
    .then(() => {
        db = client.db('shoppingCart');
        console.log('MongoDB Connected');
    })
    .catch(err => console.error('DB Connection Error:', err));

app.use((req, res, next) => {
    req.db = db;
    next();
});

// Routes
app.use('/auth', authRoutes);
app.use('/products', productRoutes);
app.use('/cart', cartRoutes);

app.listen(3000, () => console.log('Server running on port 3000'));
